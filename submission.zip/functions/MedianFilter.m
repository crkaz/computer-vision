% 
% Median Filter implementation for the sake of shorthand.
% 
function filtered = MedianFilter(im, nhood)
    filtered = medianFilter(im, nhood); % Call private function.
end

% ----------------------------------------
% % PRIVATE METHODS in ./functions/private
% ----------------------------------------
